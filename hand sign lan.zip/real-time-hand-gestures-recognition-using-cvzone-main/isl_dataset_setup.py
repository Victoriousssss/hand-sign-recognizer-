import os
import requests
import zipfile
import shutil
import json
from pathlib import Path
import subprocess
import sys

class ISLDatasetSetup:
    def __init__(self, base_dir="isl_workspace"):
        self.base_dir = base_dir
        self.dataset_dir = os.path.join(base_dir, "datasets")
        self.models_dir = os.path.join(base_dir, "models")
        self.scripts_dir = os.path.join(base_dir, "scripts")
        
        # Create directory structure
        self._create_directory_structure()
    
    def _create_directory_structure(self):
        """Create the workspace directory structure"""
        directories = [
            self.base_dir,
            self.dataset_dir,
            self.models_dir,
            self.scripts_dir,
            os.path.join(self.dataset_dir, "raw"),
            os.path.join(self.dataset_dir, "processed"),
            os.path.join(self.models_dir, "trained"),
            os.path.join(self.models_dir, "checkpoints")
        ]
        
        for directory in directories:
            os.makedirs(directory, exist_ok=True)
        
        print(f"Created workspace structure at: {self.base_dir}")
    
    def install_dependencies(self):
        """Install required dependencies"""
        print("Installing required dependencies...")
        
        dependencies = [
            "opencv-python",
            "numpy",
            "tensorflow",
            "scikit-learn",
            "matplotlib",
            "seaborn",
            "albumentations",
            "requests",
            "kaggle"  # Optional for Kaggle datasets
        ]
        
        for dep in dependencies:
            try:
                print(f"Installing {dep}...")
                subprocess.check_call([sys.executable, "-m", "pip", "install", dep])
                print(f"✓ {dep} installed successfully")
            except subprocess.CalledProcessError as e:
                print(f"✗ Failed to install {dep}: {e}")
    
    def download_sample_dataset(self):
        """Download a sample ISL dataset for testing"""
        print("Downloading sample ISL dataset...")
        
        # Sample dataset URLs (you can add more)
        sample_datasets = {
            "github_ayesha": {
                "url": "https://github.com/ayeshatasnim-h/Indian-Sign-Language-dataset/archive/refs/heads/main.zip",
                "description": "GitHub - ayeshatasnim-h/Indian-Sign-Language-dataset (12,700 images)"
            },
            "kaggle_asl": {
                "url": "https://www.kaggle.com/datasets/grassknoted/asl-alphabet",
                "description": "Kaggle - ASL Alphabet Dataset (87,000 images)",
                "requires_kaggle": True
            }
        }
        
        print("Available sample datasets:")
        for i, (key, info) in enumerate(sample_datasets.items(), 1):
            print(f"{i}. {info['description']}")
        
        choice = input("Choose dataset to download (1/2) or 'skip' to skip: ").strip()
        
        if choice == "1":
            self._download_github_dataset(sample_datasets["github_ayesha"])
        elif choice == "2":
            self._download_kaggle_dataset(sample_datasets["kaggle_asl"])
        elif choice.lower() == "skip":
            print("Skipping dataset download")
        else:
            print("Invalid choice. Skipping dataset download")
    
    def _download_github_dataset(self, dataset_info):
        """Download dataset from GitHub"""
        try:
            print(f"Downloading from: {dataset_info['url']}")
            response = requests.get(dataset_info['url'], stream=True)
            response.raise_for_status()
            
            zip_path = os.path.join(self.dataset_dir, "raw", "dataset.zip")
            
            with open(zip_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)
            
            # Extract zip file
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(os.path.join(self.dataset_dir, "raw"))
            
            # Clean up zip file
            os.remove(zip_path)
            
            print("✓ Dataset downloaded and extracted successfully!")
            self._organize_github_dataset()
            
        except Exception as e:
            print(f"✗ Error downloading dataset: {e}")
    
    def _download_kaggle_dataset(self, dataset_info):
        """Download dataset from Kaggle"""
        try:
            import kaggle
            print("Downloading from Kaggle...")
            kaggle.api.dataset_download_files(
                'grassknoted/asl-alphabet', 
                path=os.path.join(self.dataset_dir, "raw"), 
                unzip=True
            )
            print("✓ Kaggle dataset downloaded successfully!")
            
        except ImportError:
            print("✗ Kaggle API not installed. Please install with: pip install kaggle")
            print("Or download manually from: https://www.kaggle.com/datasets/grassknoted/asl-alphabet")
        except Exception as e:
            print(f"✗ Error downloading from Kaggle: {e}")
    
    def _organize_github_dataset(self):
        """Organize the downloaded GitHub dataset"""
        raw_dir = os.path.join(self.dataset_dir, "raw")
        
        # Find the extracted folder
        for item in os.listdir(raw_dir):
            item_path = os.path.join(raw_dir, item)
            if os.path.isdir(item_path) and "Indian-Sign-Language-dataset" in item:
                # Move contents to organized structure
                self._organize_dataset_structure(item_path)
                break
    
    def _organize_dataset_structure(self, source_dir):
        """Organize dataset into proper folder structure"""
        print("Organizing dataset structure...")
        
        # Create organized structure
        organized_dir = os.path.join(self.dataset_dir, "raw", "organized")
        os.makedirs(organized_dir, exist_ok=True)
        
        # Create A-Z folders
        for letter in [chr(i) for i in range(ord('A'), ord('Z') + 1)]:
            os.makedirs(os.path.join(organized_dir, letter), exist_ok=True)
        
        # This is a placeholder - you would need to implement the actual organization
        # based on the specific dataset structure
        print("Dataset organization completed!")
        print("Note: You may need to manually organize images into A-Z folders")
    
    def create_sample_data(self):
        """Create sample data for testing if no dataset is available"""
        print("Creating sample data structure...")
        
        sample_dir = os.path.join(self.dataset_dir, "raw", "sample")
        
        # Create A-Z folders
        for letter in [chr(i) for i in range(ord('A'), ord('Z') + 1)]:
            letter_dir = os.path.join(sample_dir, letter)
            os.makedirs(letter_dir, exist_ok=True)
            
            # Create a placeholder file
            placeholder_path = os.path.join(letter_dir, f"placeholder_{letter}.txt")
            with open(placeholder_path, 'w') as f:
                f.write(f"Placeholder for letter {letter} images\n")
                f.write("Replace this file with actual ISL gesture images\n")
        
        print("✓ Sample data structure created!")
        print(f"Add your ISL gesture images to: {sample_dir}")
    
    def setup_detection_scripts(self):
        """Copy and setup detection scripts"""
        print("Setting up detection scripts...")
        
        # List of detection scripts to copy
        detection_scripts = [
            "indian_sign_language_detection.py",
            "simple_isl_detection.py",
            "simple_alphabet_detection.py",
            "alphabet_detection.py",
            "cvzone_real_time_detection.py"
        ]
        
        for script in detection_scripts:
            if os.path.exists(script):
                dest_path = os.path.join(self.scripts_dir, script)
                shutil.copy2(script, dest_path)
                print(f"✓ Copied {script}")
            else:
                print(f"✗ {script} not found")
    
    def create_config_file(self):
        """Create configuration file for the workspace"""
        config = {
            "workspace": {
                "base_dir": self.base_dir,
                "dataset_dir": self.dataset_dir,
                "models_dir": self.models_dir,
                "scripts_dir": self.scripts_dir
            },
            "dataset": {
                "img_size": 224,
                "num_classes": 26,
                "labels": [chr(i) for i in range(ord('A'), ord('Z') + 1)]
            },
            "model": {
                "input_shape": [224, 224, 3],
                "num_classes": 26,
                "model_types": ["custom", "mobilenet", "resnet", "efficientnet"]
            },
            "training": {
                "batch_size": 32,
                "epochs": 100,
                "learning_rate": 0.001,
                "validation_split": 0.2
            }
        }
        
        config_path = os.path.join(self.base_dir, "config.json")
        with open(config_path, 'w') as f:
            json.dump(config, f, indent=2)
        
        print(f"✓ Configuration file created: {config_path}")
    
    def create_setup_script(self):
        """Create a setup script for easy execution"""
        setup_script = f"""#!/usr/bin/env python3
\"\"\"
ISL Dataset Setup Script
This script sets up the complete ISL workspace
\"\"\"

import os
import sys
import subprocess

def main():
    print("ISL Dataset Setup")
    print("=" * 50)
    
    # Change to workspace directory
    os.chdir("{self.base_dir}")
    
    # Run preprocessing
    print("\\n1. Running data preprocessing...")
    subprocess.run([sys.executable, "../isl_data_preprocessing.py"])
    
    # Run training
    print("\\n2. Running model training...")
    subprocess.run([sys.executable, "../isl_model_training.py"])
    
    print("\\nSetup completed!")
    print("You can now run the detection scripts from the scripts/ directory")

if __name__ == "__main__":
    main()
"""
        
        setup_path = os.path.join(self.base_dir, "setup_isl.py")
        with open(setup_path, 'w') as f:
            f.write(setup_script)
        
        print(f"✓ Setup script created: {setup_path}")
    
    def create_readme(self):
        """Create README for the workspace"""
        readme_content = f"""# ISL (Indian Sign Language) Workspace

This workspace contains everything needed for Indian Sign Language gesture recognition.

## Directory Structure

```
{self.base_dir}/
├── datasets/
│   ├── raw/           # Raw dataset files
│   └── processed/     # Preprocessed data
├── models/
│   ├── trained/       # Trained models
│   └── checkpoints/   # Training checkpoints
├── scripts/           # Detection scripts
├── config.json        # Configuration file
└── setup_isl.py      # Setup script
```

## Quick Start

1. **Setup the workspace:**
   ```bash
   python isl_dataset_setup.py
   ```

2. **Add your ISL dataset:**
   - Place your ISL gesture images in `datasets/raw/`
   - Organize images into A-Z folders

3. **Preprocess the data:**
   ```bash
   python isl_data_preprocessing.py
   ```

4. **Train the model:**
   ```bash
   python isl_model_training.py
   ```

5. **Run detection:**
   ```bash
   cd scripts/
   python indian_sign_language_detection.py
   ```

## Available Scripts

- `indian_sign_language_detection.py` - Advanced ISL detection
- `simple_isl_detection.py` - Simple ISL detection
- `simple_alphabet_detection.py` - General alphabet detection
- `alphabet_detection.py` - Advanced alphabet detection
- `cvzone_real_time_detection.py` - Original gesture detection

## Dataset Requirements

- Images should be organized in A-Z folders
- Supported formats: PNG, JPG, JPEG
- Recommended size: 224x224 pixels
- Minimum images per class: 100 (recommended: 500+)

## Model Types

1. **Custom CNN** - Custom convolutional neural network
2. **MobileNetV2** - Transfer learning with MobileNetV2
3. **ResNet50** - Transfer learning with ResNet50
4. **EfficientNetB0** - Transfer learning with EfficientNetB0

## Troubleshooting

- Ensure all dependencies are installed
- Check dataset structure and image formats
- Verify model files are in the correct location
- Check camera permissions for real-time detection

## Support

For issues and questions, please check the individual script documentation.
"""
        
        readme_path = os.path.join(self.base_dir, "README.md")
        with open(readme_path, 'w') as f:
            f.write(readme_content)
        
        print(f"✓ README created: {readme_path}")
    
    def run_setup(self):
        """Run the complete setup process"""
        print("=" * 60)
        print("ISL DATASET WORKSPACE SETUP")
        print("=" * 60)
        
        try:
            # Step 1: Install dependencies
            self.install_dependencies()
            
            # Step 2: Download sample dataset
            self.download_sample_dataset()
            
            # Step 3: Create sample data if needed
            if not os.path.exists(os.path.join(self.dataset_dir, "raw", "organized")):
                self.create_sample_data()
            
            # Step 4: Setup detection scripts
            self.setup_detection_scripts()
            
            # Step 5: Create configuration file
            self.create_config_file()
            
            # Step 6: Create setup script
            self.create_setup_script()
            
            # Step 7: Create README
            self.create_readme()
            
            print("\n" + "=" * 60)
            print("SETUP COMPLETED!")
            print("=" * 60)
            print(f"Workspace created at: {self.base_dir}")
            print("\nNext steps:")
            print("1. Add your ISL dataset images to datasets/raw/")
            print("2. Run: python isl_data_preprocessing.py")
            print("3. Run: python isl_model_training.py")
            print("4. Run detection scripts from scripts/ directory")
            print(f"\nFor detailed instructions, see: {os.path.join(self.base_dir, 'README.md')}")
            
        except Exception as e:
            print(f"Error during setup: {e}")
            print("Please check the error and try again")

if __name__ == "__main__":
    # Create setup instance
    setup = ISLDatasetSetup()
    
    # Run setup
    setup.run_setup()
