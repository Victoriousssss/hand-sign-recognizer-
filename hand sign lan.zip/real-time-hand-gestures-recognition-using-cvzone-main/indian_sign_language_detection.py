import cv2
from cvzone.HandTrackingModule import HandDetector
from cvzone.ClassificationModule import Classifier
import numpy as np
import math
import time

class IndianSignLanguageDetector:
    def __init__(self):
        self.cap = cv2.VideoCapture(0)
        self.detector = HandDetector(maxHands=1)
        self.classifier = Classifier('keras_model.h5', "labels.txt")
        
        # Load labels from file
        with open("labels.txt", "r") as f:
            self.labels = [line.strip().split()[1] for line in f.readlines()]
        
        # ISL gesture descriptions for help
        self.isl_descriptions = {
            'A': 'Fist with thumb extended to the side',
            'B': 'All fingers extended, palm facing forward',
            'C': 'Fingers curved like a C shape',
            'D': 'Index finger pointing up, other fingers closed',
            'E': 'All fingers closed, thumb across fingers',
            'F': 'Index and middle finger extended, others closed',
            'G': 'Index finger pointing forward, others closed',
            'H': 'Index and middle finger extended side by side',
            'I': 'Pinky finger extended, others closed',
            'J': 'Pinky finger extended, make J motion',
            'K': 'Index and middle finger extended, thumb between them',
            'L': 'Index finger and thumb extended, others closed',
            'M': 'All fingers closed, thumb under other fingers',
            'N': 'Index and middle finger closed, others extended',
            'O': 'All fingers curved to form O shape',
            'P': 'Index finger pointing up, middle finger down, others closed',
            'Q': 'Index finger and thumb extended, others closed',
            'R': 'Index and middle finger crossed',
            'S': 'Fist with thumb across fingers',
            'T': 'Fist with thumb between index and middle finger',
            'U': 'Index and middle finger extended together',
            'V': 'Index and middle finger extended apart',
            'W': 'Index, middle, and ring finger extended',
            'X': 'Index finger bent, others closed',
            'Y': 'Thumb and pinky extended, others closed',
            'Z': 'Index finger moving in Z pattern'
        }
        
        self.offset = 20
        self.imgSize = 300
        
        # For smooth detection
        self.last_prediction = None
        self.prediction_count = 0
        self.prediction_threshold = 5  # Number of consistent predictions needed
        self.current_letter = "None"
        self.confidence_threshold = 0.6
        
        # For word building
        self.detected_word = ""
        self.last_letter_time = 0
        self.letter_delay = 2.0  # Seconds to wait before adding letter to word
        
        # For ISL-specific features
        self.show_help = True
        self.help_duration = 10  # Show help for 10 seconds
        self.start_time = time.time()
        
        print(f"Loaded {len(self.labels)} ISL alphabet classes: {self.labels}")
        print("Indian Sign Language Detection System Initialized")

    def preprocess_hand(self, img, hand_bbox):
        """Preprocess the hand region for classification"""
        x, y, w, h = hand_bbox
        
        # Create white background
        imgWhite = np.ones((self.imgSize, self.imgSize, 3), np.uint8) * 255
        
        # Crop hand region with offset
        imgCrop = img[y - self.offset:y + h + self.offset, 
                     x - self.offset:x + w + self.offset]
        
        if imgCrop.size == 0:
            return None
            
        aspectRatio = h / w
        
        if aspectRatio > 1:
            # Height is greater than width
            k = self.imgSize / h
            wCal = math.ceil(k * w)
            imgResize = cv2.resize(imgCrop, (wCal, self.imgSize))
            wGap = math.ceil((self.imgSize - wCal) / 2)
            imgWhite[:, wGap:wCal + wGap] = imgResize
        else:
            # Width is greater than height
            k = self.imgSize / w
            hCal = math.ceil(k * h)
            imgResize = cv2.resize(imgCrop, (self.imgSize, hCal))
            hGap = math.ceil((self.imgSize - hCal) / 2)
            imgWhite[hGap:hCal + hGap, :] = imgResize
            
        return imgWhite

    def update_word(self, letter):
        """Update the detected word with new letter"""
        current_time = time.time()
        
        # If it's a new letter or enough time has passed, add to word
        if (letter != self.current_letter or 
            current_time - self.last_letter_time > self.letter_delay):
            
            if letter != self.current_letter and letter != "None":
                self.detected_word += letter
                print(f"Added '{letter}' to word. Current word: '{self.detected_word}'")
            
            self.current_letter = letter
            self.last_letter_time = current_time

    def draw_ui(self, img, prediction, confidence, hand_bbox):
        """Draw the user interface on the image"""
        x, y, w, h = hand_bbox
        
        # Draw bounding box around hand
        cv2.rectangle(img, (x - self.offset, y - self.offset),
                     (x + w + self.offset, y + h + self.offset), (0, 255, 0), 2)
        
        # Draw prediction box with ISL styling
        cv2.rectangle(img, (x - self.offset, y - self.offset - 120),
                     (x + 300, y - self.offset - 20), (0, 100, 200), cv2.FILLED)
        
        # Draw prediction text
        cv2.putText(img, f"ISL Letter: {prediction}", 
                   (x - self.offset + 5, y - self.offset - 90), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        
        # Draw confidence
        cv2.putText(img, f"Confidence: {confidence:.2f}", 
                   (x - self.offset + 5, y - self.offset - 65), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
        
        # Draw gesture description
        if prediction in self.isl_descriptions:
            desc = self.isl_descriptions[prediction]
            # Split long descriptions into multiple lines
            if len(desc) > 30:
                desc = desc[:30] + "..."
            cv2.putText(img, f"Gesture: {desc}", 
                       (x - self.offset + 5, y - self.offset - 40), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
        
        # Draw current word
        cv2.putText(img, f"Current Word: {self.detected_word}", 
                   (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 100, 200), 2)
        
        # Draw current alphabet in top right corner
        if hasattr(self, 'current_letter') and self.current_letter != "None":
            # Get image dimensions
            height, width = img.shape[:2]
            
            # Create background box for current letter
            box_width = 200
            box_height = 80
            x_pos = width - box_width - 20
            y_pos = 20
            
            # Draw background rectangle
            cv2.rectangle(img, (x_pos, y_pos), (x_pos + box_width, y_pos + box_height), (0, 100, 200), -1)
            cv2.rectangle(img, (x_pos, y_pos), (x_pos + box_width, y_pos + box_height), (255, 255, 255), 2)
            
            # Draw current letter
            cv2.putText(img, f"Current Letter: {self.current_letter}", 
                       (x_pos + 10, y_pos + 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
            
            # Draw gesture description if available
            if self.current_letter in self.isl_descriptions:
                desc = self.isl_descriptions[self.current_letter]['description']
                if len(desc) > 25:
                    desc = desc[:25] + "..."
                cv2.putText(img, desc, (x_pos + 10, y_pos + 55), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
        
        # Draw instructions
        cv2.putText(img, "Press 'h' for help, 'c' to clear word, 'q' to quit", 
                   (10, img.shape[0] - 20), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)

    def draw_help_screen(self, img):
        """Draw help screen with ISL gesture descriptions"""
        # Semi-transparent overlay
        overlay = img.copy()
        cv2.rectangle(overlay, (0, 0), (img.shape[1], img.shape[0]), (0, 0, 0), -1)
        cv2.addWeighted(overlay, 0.7, img, 0.3, 0, img)
        
        # Help title
        cv2.putText(img, "Indian Sign Language (ISL) Gesture Guide", 
                   (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1.2, (0, 255, 255), 2)
        
        # Show first 10 letters with descriptions
        y_offset = 100
        for i, (letter, desc) in enumerate(list(self.isl_descriptions.items())[:10]):
            cv2.putText(img, f"{letter}: {desc}", 
                       (50, y_offset + i * 30), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)
        
        # Show remaining letters
        y_offset = 100
        for i, (letter, desc) in enumerate(list(self.isl_descriptions.items())[10:20]):
            cv2.putText(img, f"{letter}: {desc}", 
                       (400, y_offset + i * 30), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)
        
        # Show last letters
        y_offset = 100
        for i, (letter, desc) in enumerate(list(self.isl_descriptions.items())[20:]):
            cv2.putText(img, f"{letter}: {desc}", 
                       (750, y_offset + i * 30), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)
        
        # Instructions
        cv2.putText(img, "Press 'h' to toggle help, 'q' to quit", 
                   (50, img.shape[0] - 50), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 255), 2)

    def run(self):
        """Main detection loop"""
        print("Starting Indian Sign Language Detection...")
        print("Instructions:")
        print("- Show ISL hand gestures for letters A-Z")
        print("- Press 'h' to toggle help screen")
        print("- Press 'c' to clear the current word")
        print("- Press 'q' to quit")
        print("- Hold each letter gesture for a moment to add it to the word")
        
        while True:
            success, img = self.cap.read()
            if not success:
                break
                
            imgOutput = img.copy()
            
            # Show help screen if enabled
            if self.show_help:
                self.draw_help_screen(imgOutput)
            else:
                hands, img = self.detector.findHands(img, draw=False)
                
                if hands:
                    hand = hands[0]
                    bbox = hand['bbox']
                    
                    # Preprocess hand for classification
                    imgWhite = self.preprocess_hand(img, bbox)
                    
                    if imgWhite is not None:
                        # Get prediction
                        prediction, index = self.classifier.getPrediction(imgWhite, draw=False)
                        confidence = prediction[index]
                        
                        # Smooth prediction with threshold
                        if confidence > self.confidence_threshold:
                            if prediction == self.last_prediction:
                                self.prediction_count += 1
                            else:
                                self.prediction_count = 1
                                self.last_prediction = prediction
                            
                            # Only update if we have consistent predictions
                            if self.prediction_count >= self.prediction_threshold:
                                letter = self.labels[index]
                                self.update_word(letter)
                                self.draw_ui(imgOutput, letter, confidence, bbox)
                            else:
                                self.draw_ui(imgOutput, "Processing...", confidence, bbox)
                        else:
                            self.draw_ui(imgOutput, "Low Confidence", confidence, bbox)
                    
                    # Show cropped hand and processed image
                    cv2.imshow("Hand Crop", imgCrop if 'imgCrop' in locals() else np.zeros((100, 100, 3), np.uint8))
                    cv2.imshow("Processed Hand", imgWhite if 'imgWhite' in locals() else np.zeros((100, 100, 3), np.uint8))
                else:
                    # No hand detected
                    cv2.putText(imgOutput, "No Hand Detected - Show ISL Gesture", 
                               (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
                    cv2.putText(imgOutput, f"Current Word: {self.detected_word}", 
                               (10, 70), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 100, 200), 2)
                    cv2.putText(imgOutput, "Press 'h' for help, 'c' to clear word, 'q' to quit", 
                               (10, img.shape[0] - 20), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)
            
            cv2.imshow("Indian Sign Language Detection", imgOutput)
            
            # Handle key presses
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break
            elif key == ord('c'):
                self.detected_word = ""
                self.current_letter = "None"
                print("Word cleared!")
            elif key == ord('h'):
                self.show_help = not self.show_help
                print("Help toggled!")
        
        self.cleanup()

    def cleanup(self):
        """Clean up resources"""
        self.cap.release()
        cv2.destroyAllWindows()
        print(f"Final word: '{self.detected_word}'")

if __name__ == "__main__":
    detector = IndianSignLanguageDetector()
    detector.run()
