import cv2
import numpy as np
import time

def demo_current_alphabet_display():
    """Demo script showing how the current alphabet appears in top right corner"""
    
    # Create a demo window
    cv2.namedWindow("Current Alphabet Display Demo", cv2.WINDOW_NORMAL)
    cv2.resizeWindow("Current Alphabet Display Demo", 800, 600)
    
    # Sample alphabet letters to cycle through
    letters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
    
    # Sample gesture descriptions
    gesture_descriptions = {
        'A': 'Fist with thumb extended to the side',
        'B': 'All fingers extended, palm facing forward',
        'C': 'Fingers curved like a C shape',
        'D': 'Index finger pointing up, other fingers closed',
        'E': 'All fingers closed, thumb across fingers',
        'F': 'Index and middle finger extended, others closed',
        'G': 'Index finger pointing forward, others closed',
        'H': 'Index and middle finger extended side by side',
        'I': 'Pinky finger extended, others closed',
        'J': 'Pinky finger extended, make J motion',
        'K': 'Index and middle finger extended, thumb between them',
        'L': 'Index finger and thumb extended, others closed',
        'M': 'All fingers closed, thumb under other fingers',
        'N': 'Index and middle finger closed, others extended',
        'O': 'All fingers curved to form O shape',
        'P': 'Index finger pointing up, middle finger down, others closed',
        'Q': 'Index finger and thumb extended, others closed',
        'R': 'Index and middle finger crossed',
        'S': 'Fist with thumb across fingers',
        'T': 'Fist with thumb between index and middle finger',
        'U': 'Index and middle finger extended together',
        'V': 'Index and middle finger extended apart',
        'W': 'Index, middle, and ring finger extended',
        'X': 'Index finger bent, others closed',
        'Y': 'Thumb and pinky extended, others closed',
        'Z': 'Index finger moving in Z pattern'
    }
    
    current_index = 0
    start_time = time.time()
    
    print("Current Alphabet Display Demo")
    print("This shows how the current alphabet appears in the top right corner")
    print("Press 'q' to quit, 'n' for next letter, 'p' for previous letter")
    
    while True:
        # Create a black background
        img = np.zeros((600, 800, 3), np.uint8)
        
        # Get current letter
        current_letter = letters[current_index]
        
        # Draw main content
        cv2.putText(img, "INDIAN SIGN LANGUAGE DETECTION", 
                   (50, 100), cv2.FONT_HERSHEY_SIMPLEX, 1.5, (0, 255, 255), 2)
        
        cv2.putText(img, f"Current Word: HELLO", 
                   (50, 150), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 100, 200), 2)
        
        cv2.putText(img, "Hand Detection Area (Simulated)", 
                   (50, 250), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
        
        # Draw simulated hand detection box
        cv2.rectangle(img, (50, 280), (300, 450), (0, 255, 0), 2)
        cv2.putText(img, "Hand Gesture", (60, 320), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
        cv2.putText(img, f"Letter: {current_letter}", (60, 350), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
        cv2.putText(img, f"Confidence: 0.85", (60, 380), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
        
        # Draw current alphabet in top right corner (THE MAIN FEATURE)
        if current_letter != "None":
            # Get image dimensions
            height, width = img.shape[:2]
            
            # Create background box for current letter
            box_width = 250
            box_height = 100
            x_pos = width - box_width - 20
            y_pos = 20
            
            # Draw background rectangle with gradient effect
            cv2.rectangle(img, (x_pos, y_pos), (x_pos + box_width, y_pos + box_height), (0, 100, 200), -1)
            cv2.rectangle(img, (x_pos, y_pos), (x_pos + box_width, y_pos + box_height), (255, 255, 255), 2)
            
            # Draw current letter
            cv2.putText(img, f"Current Letter: {current_letter}", 
                       (x_pos + 10, y_pos + 30), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (255, 255, 255), 2)
            
            # Draw gesture description if available
            if current_letter in gesture_descriptions:
                desc = gesture_descriptions[current_letter]
                if len(desc) > 30:
                    desc = desc[:30] + "..."
                cv2.putText(img, desc, (x_pos + 10, y_pos + 55), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
            
            # Draw additional info
            cv2.putText(img, f"Hold to add to word", 
                       (x_pos + 10, y_pos + 75), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 0), 1)
        
        # Draw instructions
        cv2.putText(img, "Press 'n' for next letter, 'p' for previous, 'q' to quit", 
                   (50, 550), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)
        
        # Auto-advance every 2 seconds
        if time.time() - start_time > 2:
            current_index = (current_index + 1) % len(letters)
            start_time = time.time()
        
        cv2.imshow("Current Alphabet Display Demo", img)
        
        key = cv2.waitKey(30) & 0xFF
        if key == ord('q'):
            break
        elif key == ord('n'):
            current_index = (current_index + 1) % len(letters)
            start_time = time.time()
        elif key == ord('p'):
            current_index = (current_index - 1) % len(letters)
            start_time = time.time()
    
    cv2.destroyAllWindows()
    print("Demo completed!")

if __name__ == "__main__":
    demo_current_alphabet_display()
