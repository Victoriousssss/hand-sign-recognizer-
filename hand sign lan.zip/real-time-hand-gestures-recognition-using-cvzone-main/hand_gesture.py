import cv2
import numpy as np
from tensorflow.keras.models import load_model

# Load model and labels
model = load_model("keras_model.h5")

with open("labels.txt", "r") as f:
    labels = [line.strip() for line in f.readlines()]

# Open webcam
cap = cv2.VideoCapture(0)

while True:
    ret, frame = cap.read()
    if not ret:
        break

    # Resize frame to match model input (224x224, trained by Teachable Machine)
    img = cv2.resize(frame, (224, 224))
    img = np.expand_dims(img, axis=0)
    img = img.astype(np.float32) / 255.0

    # Prediction
    prediction = model.predict(img)[0]
    class_index = np.argmax(prediction)
    confidence = prediction[class_index]

    # Display prediction
    cv2.putText(frame, f"{labels[class_index]} ({confidence*100:.2f}%)",
                (10, 40), cv2.FONT_HERSHEY_SIMPLEX, 1, (0,255,0), 2)

    cv2.imshow("Hand Gesture Recognition", frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
