#!/usr/bin/env python3
"""
Indian Sign Language Alphabet Help System
This script provides multiple ways to view all alphabet gestures
"""

import subprocess
import sys
import os

def print_menu():
    """Print the main menu"""
    print("=" * 60)
    print("INDIAN SIGN LANGUAGE ALPHABET HELP SYSTEM")
    print("=" * 60)
    print()
    print("Choose your preferred help method:")
    print()
    print("1. Interactive Visual Guide (Recommended)")
    print("   - Navigate through letters with A/D keys")
    print("   - See all letters at once with SPACE")
    print("   - Filter by difficulty with F key")
    print()
    print("2. Simple Visual Guide")
    print("   - Basic navigation through letters")
    print("   - View all letters in grid format")
    print()
    print("3. Text-based Guide")
    print("   - Print all gestures to console")
    print("   - Good for reference or printing")
    print()
    print("4. Comprehensive Help System")
    print("   - Advanced features with difficulty levels")
    print("   - Multiple view modes")
    print("   - Color-coded difficulty indicators")
    print()
    print("5. Exit")
    print()
    print("=" * 60)

def run_script(script_name):
    """Run a Python script"""
    try:
        if os.path.exists(script_name):
            subprocess.run([sys.executable, script_name])
        else:
            print(f"Error: {script_name} not found!")
    except Exception as e:
        print(f"Error running {script_name}: {e}")

def main():
    """Main function"""
    while True:
        print_menu()
        choice = input("Enter your choice (1-5): ").strip()
        
        if choice == '1':
            print("\nStarting Interactive Visual Guide...")
            run_script('alphabet_help_guide.py')
        elif choice == '2':
            print("\nStarting Simple Visual Guide...")
            run_script('alphabet_help_guide.py')
        elif choice == '3':
            print("\nDisplaying Text-based Guide...")
            run_script('alphabet_help_text.py')
        elif choice == '4':
            print("\nStarting Comprehensive Help System...")
            run_script('comprehensive_help_system.py')
        elif choice == '5':
            print("\nThank you for using the ISL Alphabet Help System!")
            break
        else:
            print("\nInvalid choice! Please enter 1-5.")
        
        input("\nPress Enter to continue...")
        print("\n" * 2)

if __name__ == "__main__":
    main()
