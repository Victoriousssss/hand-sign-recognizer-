def print_alphabet_help():
    """Print all alphabet gestures in a formatted text guide"""
    
    alphabet_gestures = {
        'A': {
            'description': 'Fist with thumb extended to the side',
            'instructions': 'Make a fist with all fingers closed, extend the thumb to the side (not forward)',
            'tips': 'Keep the thumb perpendicular to the other fingers, not pointing forward'
        },
        'B': {
            'description': 'All fingers extended, palm facing forward',
            'instructions': 'Extend all five fingers straight up, palm facing forward',
            'tips': 'Keep fingers straight and slightly apart, palm flat'
        },
        'C': {
            'description': 'Fingers curved like a C shape',
            'instructions': 'Curve all fingers to form a C shape, thumb and fingers creating a semi-circle',
            'tips': 'Make sure the opening of the C is clearly visible'
        },
        'D': {
            'description': 'Index finger pointing up, other fingers closed',
            'instructions': 'Extend only the index finger upward, close all other fingers including thumb',
            'tips': 'Keep the index finger straight and pointing directly up'
        },
        'E': {
            'description': 'All fingers closed, thumb across fingers',
            'instructions': 'Make a fist with all fingers closed, place thumb across the closed fingers',
            'tips': 'The thumb should rest on top of the closed fingers'
        },
        'F': {
            'description': 'Index and middle finger extended, others closed',
            'instructions': 'Extend index and middle finger together, close ring finger, pinky, and thumb',
            'tips': 'Keep the two extended fingers close together'
        },
        'G': {
            'description': 'Index finger pointing forward, others closed',
            'instructions': 'Point index finger forward (like pointing), close all other fingers',
            'tips': 'Keep the index finger straight and pointing forward'
        },
        'H': {
            'description': 'Index and middle finger extended side by side',
            'instructions': 'Extend index and middle finger side by side, close other fingers',
            'tips': 'Keep both fingers straight and parallel to each other'
        },
        'I': {
            'description': 'Pinky finger extended, others closed',
            'instructions': 'Extend only the pinky finger, close all other fingers including thumb',
            'tips': 'Keep the pinky straight and pointing up'
        },
        'J': {
            'description': 'Pinky finger extended, make J motion',
            'instructions': 'Start with pinky extended, then make a J-shaped motion',
            'tips': 'The motion should trace the letter J in the air'
        },
        'K': {
            'description': 'Index and middle finger extended, thumb between them',
            'instructions': 'Extend index and middle finger, place thumb between them',
            'tips': 'The thumb should be positioned between the two extended fingers'
        },
        'L': {
            'description': 'Index finger and thumb extended, others closed',
            'instructions': 'Extend index finger and thumb, close middle, ring, and pinky fingers',
            'tips': 'Form an L shape with index finger and thumb'
        },
        'M': {
            'description': 'All fingers closed, thumb under other fingers',
            'instructions': 'Make a fist with all fingers closed, thumb tucked under the other fingers',
            'tips': 'The thumb should be completely hidden under the other fingers'
        },
        'N': {
            'description': 'Index and middle finger closed, others extended',
            'instructions': 'Close index and middle finger, extend ring finger, pinky, and thumb',
            'tips': 'Keep the closed fingers together, extended fingers spread'
        },
        'O': {
            'description': 'All fingers curved to form O shape',
            'instructions': 'Curve all fingers to form a perfect O shape',
            'tips': 'Make sure the O is round and complete'
        },
        'P': {
            'description': 'Index finger pointing up, middle finger down, others closed',
            'instructions': 'Point index finger up, middle finger down, close other fingers',
            'tips': 'Create a clear contrast between up and down fingers'
        },
        'Q': {
            'description': 'Index finger and thumb extended, others closed',
            'instructions': 'Extend index finger and thumb, close middle, ring, and pinky fingers',
            'tips': 'Similar to L but with different positioning'
        },
        'R': {
            'description': 'Index and middle finger crossed',
            'instructions': 'Extend index and middle finger and cross them over each other',
            'tips': 'Make sure the crossing is clearly visible'
        },
        'S': {
            'description': 'Fist with thumb across fingers',
            'instructions': 'Make a fist with all fingers closed, thumb across the closed fingers',
            'tips': 'Similar to E but with thumb positioned differently'
        },
        'T': {
            'description': 'Fist with thumb between index and middle finger',
            'instructions': 'Make a fist, place thumb between index and middle finger',
            'tips': 'The thumb should be clearly visible between the two fingers'
        },
        'U': {
            'description': 'Index and middle finger extended together',
            'instructions': 'Extend index and middle finger together, close other fingers',
            'tips': 'Keep both fingers straight and touching each other'
        },
        'V': {
            'description': 'Index and middle finger extended apart',
            'instructions': 'Extend index and middle finger apart from each other',
            'tips': 'Create a clear V shape with the two fingers'
        },
        'W': {
            'description': 'Index, middle, and ring finger extended',
            'instructions': 'Extend index, middle, and ring finger, close pinky and thumb',
            'tips': 'Keep the three extended fingers spread apart'
        },
        'X': {
            'description': 'Index finger bent, others closed',
            'instructions': 'Bend the index finger, close all other fingers',
            'tips': 'Make sure the bend in the index finger is clearly visible'
        },
        'Y': {
            'description': 'Thumb and pinky extended, others closed',
            'instructions': 'Extend thumb and pinky finger, close index, middle, and ring fingers',
            'tips': 'Create a clear Y shape with thumb and pinky'
        },
        'Z': {
            'description': 'Index finger moving in Z pattern',
            'instructions': 'Use index finger to trace a Z shape in the air',
            'tips': 'Make the Z motion clear and deliberate'
        }
    }
    
    print("=" * 80)
    print("INDIAN SIGN LANGUAGE ALPHABET GESTURE GUIDE")
    print("=" * 80)
    print()
    
    for letter, info in alphabet_gestures.items():
        print(f"LETTER: {letter}")
        print(f"Description: {info['description']}")
        print(f"Instructions: {info['instructions']}")
        print(f"Tips: {info['tips']}")
        print("-" * 60)
        print()
    
    print("GENERAL TIPS FOR ALL GESTURES:")
    print("- Ensure good lighting on your hands")
    print("- Use a plain, contrasting background")
    print("- Keep your hand at an appropriate distance from the camera")
    print("- Hold gestures steady for a few seconds")
    print("- Make gestures clear and distinct")
    print("- Don't rush the gestures")
    print("- Ensure all fingers are in the correct position")
    print("- Avoid partial gestures")
    print("- Keep hands clean and visible")
    print()
    print("=" * 80)

if __name__ == "__main__":
    print_alphabet_help()
