import os
import cv2
import numpy as np
import requests
import zipfile
import shutil
from pathlib import Path
import json
from sklearn.model_selection import train_test_split
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Conv2D, MaxPooling2D, Flatten, Dropout
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau
import matplotlib.pyplot as plt

class ISLDatasetIntegration:
    def __init__(self, dataset_path="isl_dataset", model_path="isl_model.h5"):
        self.dataset_path = dataset_path
        self.model_path = model_path
        self.labels = [chr(i) for i in range(ord('A'), ord('Z') + 1)]  # A-Z
        self.num_classes = len(self.labels)
        self.img_size = 224  # Standard size for most models
        
    def download_isl_dataset(self):
        """Download ISL dataset from various sources"""
        print("Downloading ISL Dataset...")
        
        # Create dataset directory
        os.makedirs(self.dataset_path, exist_ok=True)
        
        # Dataset URLs (you can add more sources)
        dataset_urls = {
            "github_ayesha": "https://github.com/ayeshatasnim-h/Indian-Sign-Language-dataset/archive/refs/heads/main.zip",
            "kaggle_isl": "https://www.kaggle.com/datasets/grassknoted/asl-alphabet",  # Note: Requires Kaggle API
        }
        
        print("Available dataset sources:")
        print("1. GitHub - ayeshatasnim-h/Indian-Sign-Language-dataset")
        print("2. Kaggle - ASL Alphabet Dataset")
        print("3. Manual dataset upload")
        
        choice = input("Choose dataset source (1/2/3): ").strip()
        
        if choice == "1":
            self._download_from_github(dataset_urls["github_ayesha"])
        elif choice == "2":
            self._download_from_kaggle()
        elif choice == "3":
            self._setup_manual_dataset()
        else:
            print("Invalid choice. Setting up manual dataset structure...")
            self._setup_manual_dataset()
    
    def _download_from_github(self, url):
        """Download dataset from GitHub"""
        try:
            print("Downloading from GitHub...")
            response = requests.get(url)
            response.raise_for_status()
            
            zip_path = os.path.join(self.dataset_path, "dataset.zip")
            with open(zip_path, 'wb') as f:
                f.write(response.content)
            
            # Extract zip file
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(self.dataset_path)
            
            # Clean up zip file
            os.remove(zip_path)
            print("Dataset downloaded and extracted successfully!")
            
        except Exception as e:
            print(f"Error downloading from GitHub: {e}")
            print("Please download manually and place in dataset folder")
    
    def _download_from_kaggle(self):
        """Download dataset from Kaggle (requires Kaggle API)"""
        try:
            import kaggle
            print("Downloading from Kaggle...")
            kaggle.api.dataset_download_files('grassknoted/asl-alphabet', path=self.dataset_path, unzip=True)
            print("Dataset downloaded from Kaggle successfully!")
        except ImportError:
            print("Kaggle API not installed. Please install with: pip install kaggle")
            print("Or download manually from: https://www.kaggle.com/datasets/grassknoted/asl-alphabet")
        except Exception as e:
            print(f"Error downloading from Kaggle: {e}")
    
    def _setup_manual_dataset(self):
        """Set up manual dataset structure"""
        print("Setting up manual dataset structure...")
        
        # Create directory structure
        for letter in self.labels:
            letter_dir = os.path.join(self.dataset_path, letter)
            os.makedirs(letter_dir, exist_ok=True)
        
        print(f"Dataset structure created at: {self.dataset_path}")
        print("Please add your ISL gesture images to the respective letter folders")
        print("Example: A/ folder should contain images of letter A gestures")
    
    def preprocess_dataset(self):
        """Preprocess the dataset for training"""
        print("Preprocessing dataset...")
        
        images = []
        labels = []
        
        for i, letter in enumerate(self.labels):
            letter_dir = os.path.join(self.dataset_path, letter)
            if not os.path.exists(letter_dir):
                print(f"Warning: Directory {letter_dir} not found")
                continue
            
            print(f"Processing letter: {letter}")
            letter_images = []
            
            for filename in os.listdir(letter_dir):
                if filename.lower().endswith(('.png', '.jpg', '.jpeg')):
                    img_path = os.path.join(letter_dir, filename)
                    try:
                        # Load and preprocess image
                        img = cv2.imread(img_path)
                        if img is not None:
                            # Resize to standard size
                            img = cv2.resize(img, (self.img_size, self.img_size))
                            # Convert BGR to RGB
                            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
                            # Normalize pixel values
                            img = img.astype(np.float32) / 255.0
                            letter_images.append(img)
                    except Exception as e:
                        print(f"Error processing {img_path}: {e}")
            
            print(f"Found {len(letter_images)} images for letter {letter}")
            images.extend(letter_images)
            labels.extend([i] * len(letter_images))
        
        if not images:
            raise ValueError("No images found in dataset. Please check your dataset structure.")
        
        # Convert to numpy arrays
        X = np.array(images)
        y = np.array(labels)
        
        # Convert labels to categorical
        y_categorical = to_categorical(y, self.num_classes)
        
        print(f"Dataset preprocessed: {X.shape[0]} images, {X.shape[1]}x{X.shape[2]} pixels")
        return X, y_categorical
    
    def create_model(self):
        """Create CNN model for ISL recognition"""
        model = Sequential([
            Conv2D(32, (3, 3), activation='relu', input_shape=(self.img_size, self.img_size, 3)),
            MaxPooling2D(2, 2),
            
            Conv2D(64, (3, 3), activation='relu'),
            MaxPooling2D(2, 2),
            
            Conv2D(128, (3, 3), activation='relu'),
            MaxPooling2D(2, 2),
            
            Conv2D(128, (3, 3), activation='relu'),
            MaxPooling2D(2, 2),
            
            Flatten(),
            Dropout(0.5),
            Dense(512, activation='relu'),
            Dropout(0.5),
            Dense(self.num_classes, activation='softmax')
        ])
        
        model.compile(
            optimizer=Adam(learning_rate=0.001),
            loss='categorical_crossentropy',
            metrics=['accuracy']
        )
        
        return model
    
    def train_model(self, X, y, validation_split=0.2, epochs=50):
        """Train the ISL model"""
        print("Training ISL model...")
        
        # Split data
        X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=validation_split, random_state=42)
        
        # Create model
        model = self.create_model()
        
        # Callbacks
        callbacks = [
            EarlyStopping(patience=10, restore_best_weights=True),
            ReduceLROnPlateau(factor=0.5, patience=5)
        ]
        
        # Train model
        history = model.fit(
            X_train, y_train,
            validation_data=(X_val, y_val),
            epochs=epochs,
            batch_size=32,
            callbacks=callbacks,
            verbose=1
        )
        
        # Save model
        model.save(self.model_path)
        print(f"Model saved to: {self.model_path}")
        
        # Save training history
        self._save_training_history(history)
        
        return model, history
    
    def _save_training_history(self, history):
        """Save training history for analysis"""
        history_path = os.path.join(self.dataset_path, "training_history.json")
        
        history_dict = {
            'loss': history.history['loss'],
            'accuracy': history.history['accuracy'],
            'val_loss': history.history['val_loss'],
            'val_accuracy': history.history['val_accuracy']
        }
        
        with open(history_path, 'w') as f:
            json.dump(history_dict, f)
        
        print(f"Training history saved to: {history_path}")
    
    def plot_training_history(self, history):
        """Plot training history"""
        plt.figure(figsize=(12, 4))
        
        plt.subplot(1, 2, 1)
        plt.plot(history.history['loss'], label='Training Loss')
        plt.plot(history.history['val_loss'], label='Validation Loss')
        plt.title('Model Loss')
        plt.xlabel('Epoch')
        plt.ylabel('Loss')
        plt.legend()
        
        plt.subplot(1, 2, 2)
        plt.plot(history.history['accuracy'], label='Training Accuracy')
        plt.plot(history.history['val_accuracy'], label='Validation Accuracy')
        plt.title('Model Accuracy')
        plt.xlabel('Epoch')
        plt.ylabel('Accuracy')
        plt.legend()
        
        plt.tight_layout()
        plt.savefig(os.path.join(self.dataset_path, 'training_plots.png'))
        plt.show()
    
    def evaluate_model(self, model, X_test, y_test):
        """Evaluate the trained model"""
        print("Evaluating model...")
        
        # Get predictions
        predictions = model.predict(X_test)
        predicted_classes = np.argmax(predictions, axis=1)
        true_classes = np.argmax(y_test, axis=1)
        
        # Calculate accuracy
        accuracy = np.mean(predicted_classes == true_classes)
        print(f"Test Accuracy: {accuracy:.4f}")
        
        # Print per-class accuracy
        print("\nPer-class accuracy:")
        for i, letter in enumerate(self.labels):
            class_mask = true_classes == i
            if np.sum(class_mask) > 0:
                class_accuracy = np.mean(predicted_classes[class_mask] == true_classes[class_mask])
                print(f"{letter}: {class_accuracy:.4f}")
        
        return accuracy
    
    def create_isl_labels_file(self):
        """Create labels.txt file for the detection scripts"""
        labels_path = "isl_labels.txt"
        
        with open(labels_path, 'w') as f:
            for i, letter in enumerate(self.labels):
                f.write(f"{i} {letter}\n")
        
        print(f"ISL labels file created: {labels_path}")
        return labels_path
    
    def run_full_pipeline(self):
        """Run the complete ISL dataset integration pipeline"""
        print("=" * 60)
        print("ISL DATASET INTEGRATION PIPELINE")
        print("=" * 60)
        
        try:
            # Step 1: Download dataset
            self.download_isl_dataset()
            
            # Step 2: Preprocess dataset
            X, y = self.preprocess_dataset()
            
            # Step 3: Train model
            model, history = self.train_model(X, y)
            
            # Step 4: Plot training history
            self.plot_training_history(history)
            
            # Step 5: Create labels file
            self.create_isl_labels_file()
            
            print("\n" + "=" * 60)
            print("ISL DATASET INTEGRATION COMPLETED!")
            print("=" * 60)
            print(f"Model saved to: {self.model_path}")
            print(f"Labels file: isl_labels.txt")
            print("\nTo use with detection scripts:")
            print("1. Copy isl_model.h5 to your detection script directory")
            print("2. Copy isl_labels.txt to your detection script directory")
            print("3. Update your detection script to use the new model and labels")
            
        except Exception as e:
            print(f"Error in pipeline: {e}")
            print("Please check your dataset and try again")

if __name__ == "__main__":
    # Create ISL dataset integration instance
    isl_integration = ISLDatasetIntegration()
    
    # Run the full pipeline
    isl_integration.run_full_pipeline()
