import os
import cv2
import numpy as np
import json
from pathlib import Path
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from tensorflow.keras.utils import to_categorical
import albumentations as A
from albumentations.pytorch import ToTensorV2

class ISLDataPreprocessor:
    def __init__(self, dataset_path="isl_dataset", output_path="processed_isl_dataset"):
        self.dataset_path = dataset_path
        self.output_path = output_path
        self.labels = [chr(i) for i in range(ord('A'), ord('Z') + 1)]  # A-Z
        self.img_size = 224
        self.augmentation_pipeline = self._create_augmentation_pipeline()
        
    def _create_augmentation_pipeline(self):
        """Create data augmentation pipeline for ISL gestures"""
        return A.Compose([
            A.RandomRotate90(p=0.3),
            A.Rotate(limit=15, p=0.5),
            A.RandomBrightnessContrast(brightness_limit=0.2, contrast_limit=0.2, p=0.5),
            A.HueSaturationValue(hue_shift_limit=20, sat_shift_limit=30, val_shift_limit=20, p=0.5),
            A.RandomGamma(gamma_limit=(80, 120), p=0.3),
            A.GaussNoise(var_limit=(10.0, 50.0), p=0.3),
            A.Blur(blur_limit=3, p=0.2),
            A.MotionBlur(blur_limit=3, p=0.2),
            A.CLAHE(clip_limit=2.0, tile_grid_size=(8, 8), p=0.3),
            A.RandomShadow(p=0.2),
            A.RandomFog(fog_coef_lower=0.1, fog_coef_upper=0.3, alpha_coef=0.1, p=0.2),
        ])
    
    def analyze_dataset(self):
        """Analyze the dataset structure and statistics"""
        print("Analyzing ISL Dataset...")
        
        dataset_stats = {
            'total_images': 0,
            'images_per_class': {},
            'class_distribution': {},
            'image_sizes': [],
            'missing_classes': []
        }
        
        for letter in self.labels:
            letter_dir = os.path.join(self.dataset_path, letter)
            if not os.path.exists(letter_dir):
                dataset_stats['missing_classes'].append(letter)
                dataset_stats['images_per_class'][letter] = 0
                continue
            
            # Count images in this class
            image_files = [f for f in os.listdir(letter_dir) 
                          if f.lower().endswith(('.png', '.jpg', '.jpeg'))]
            dataset_stats['images_per_class'][letter] = len(image_files)
            dataset_stats['total_images'] += len(image_files)
            
            # Analyze image sizes
            for img_file in image_files[:5]:  # Sample first 5 images
                img_path = os.path.join(letter_dir, img_file)
                try:
                    img = cv2.imread(img_path)
                    if img is not None:
                        dataset_stats['image_sizes'].append(img.shape)
                except:
                    pass
        
        # Calculate class distribution
        for letter, count in dataset_stats['images_per_class'].items():
            if dataset_stats['total_images'] > 0:
                dataset_stats['class_distribution'][letter] = count / dataset_stats['total_images']
            else:
                dataset_stats['class_distribution'][letter] = 0
        
        # Save analysis results
        analysis_path = os.path.join(self.output_path, "dataset_analysis.json")
        os.makedirs(self.output_path, exist_ok=True)
        
        with open(analysis_path, 'w') as f:
            json.dump(dataset_stats, f, indent=2)
        
        # Print analysis
        self._print_dataset_analysis(dataset_stats)
        
        return dataset_stats
    
    def _print_dataset_analysis(self, stats):
        """Print dataset analysis results"""
        print("\n" + "=" * 50)
        print("DATASET ANALYSIS RESULTS")
        print("=" * 50)
        print(f"Total Images: {stats['total_images']}")
        print(f"Number of Classes: {len(self.labels)}")
        print(f"Missing Classes: {stats['missing_classes']}")
        
        print("\nImages per Class:")
        for letter in self.labels:
            count = stats['images_per_class'][letter]
            percentage = stats['class_distribution'][letter] * 100
            print(f"  {letter}: {count} images ({percentage:.1f}%)")
        
        if stats['image_sizes']:
            sizes = np.array(stats['image_sizes'])
            print(f"\nImage Size Statistics:")
            print(f"  Average: {np.mean(sizes, axis=0).astype(int)}")
            print(f"  Min: {np.min(sizes, axis=0)}")
            print(f"  Max: {np.max(sizes, axis=0)}")
    
    def preprocess_images(self, augment_data=True, augmentation_factor=2):
        """Preprocess and augment images"""
        print("Preprocessing ISL images...")
        
        # Create output directories
        os.makedirs(self.output_path, exist_ok=True)
        
        processed_data = {
            'images': [],
            'labels': [],
            'class_names': self.labels
        }
        
        for i, letter in enumerate(self.labels):
            letter_dir = os.path.join(self.dataset_path, letter)
            if not os.path.exists(letter_dir):
                print(f"Warning: Directory {letter_dir} not found, skipping...")
                continue
            
            print(f"Processing letter: {letter}")
            letter_images = []
            
            # Process original images
            for filename in os.listdir(letter_dir):
                if filename.lower().endswith(('.png', '.jpg', '.jpeg')):
                    img_path = os.path.join(letter_dir, filename)
                    try:
                        processed_img = self._preprocess_single_image(img_path)
                        if processed_img is not None:
                            letter_images.append(processed_img)
                    except Exception as e:
                        print(f"Error processing {img_path}: {e}")
            
            # Data augmentation
            if augment_data and letter_images:
                print(f"  Augmenting {len(letter_images)} images...")
                augmented_images = self._augment_images(letter_images, augmentation_factor)
                letter_images.extend(augmented_images)
            
            print(f"  Total images for {letter}: {len(letter_images)}")
            
            # Add to processed data
            processed_data['images'].extend(letter_images)
            processed_data['labels'].extend([i] * len(letter_images))
        
        # Convert to numpy arrays
        X = np.array(processed_data['images'])
        y = np.array(processed_data['labels'])
        
        # Save processed data
        self._save_processed_data(X, y)
        
        print(f"\nPreprocessing completed!")
        print(f"Total processed images: {len(X)}")
        print(f"Image shape: {X.shape}")
        
        return X, y
    
    def _preprocess_single_image(self, img_path):
        """Preprocess a single image"""
        # Load image
        img = cv2.imread(img_path)
        if img is None:
            return None
        
        # Convert BGR to RGB
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        
        # Resize to standard size
        img = cv2.resize(img, (self.img_size, self.img_size))
        
        # Normalize pixel values
        img = img.astype(np.float32) / 255.0
        
        return img
    
    def _augment_images(self, images, augmentation_factor):
        """Augment images using the augmentation pipeline"""
        augmented_images = []
        
        for _ in range(augmentation_factor):
            for img in images:
                try:
                    # Convert back to uint8 for augmentation
                    img_uint8 = (img * 255).astype(np.uint8)
                    
                    # Apply augmentation
                    augmented = self.augmentation_pipeline(image=img_uint8)
                    augmented_img = augmented['image']
                    
                    # Convert back to float32 and normalize
                    augmented_img = augmented_img.astype(np.float32) / 255.0
                    augmented_images.append(augmented_img)
                    
                except Exception as e:
                    print(f"Error in augmentation: {e}")
                    continue
        
        return augmented_images
    
    def _save_processed_data(self, X, y):
        """Save processed data to files"""
        # Save as numpy arrays
        np.save(os.path.join(self.output_path, 'X_processed.npy'), X)
        np.save(os.path.join(self.output_path, 'y_processed.npy'), y)
        
        # Save metadata
        metadata = {
            'num_samples': len(X),
            'image_shape': X.shape[1:],
            'num_classes': len(self.labels),
            'class_names': self.labels,
            'img_size': self.img_size
        }
        
        with open(os.path.join(self.output_path, 'metadata.json'), 'w') as f:
            json.dump(metadata, f, indent=2)
        
        print(f"Processed data saved to: {self.output_path}")
    
    def create_train_test_split(self, X, y, test_size=0.2, validation_size=0.2):
        """Create train, validation, and test splits"""
        print("Creating train/validation/test splits...")
        
        # First split: train+val vs test
        X_temp, X_test, y_temp, y_test = train_test_split(
            X, y, test_size=test_size, random_state=42, stratify=y
        )
        
        # Second split: train vs val
        val_size_adjusted = validation_size / (1 - test_size)
        X_train, X_val, y_train, y_val = train_test_split(
            X_temp, y_temp, test_size=val_size_adjusted, random_state=42, stratify=y_temp
        )
        
        # Convert labels to categorical
        y_train_cat = to_categorical(y_train, len(self.labels))
        y_val_cat = to_categorical(y_val, len(self.labels))
        y_test_cat = to_categorical(y_test, len(self.labels))
        
        # Save splits
        splits = {
            'X_train': X_train, 'y_train': y_train_cat,
            'X_val': X_val, 'y_val': y_val_cat,
            'X_test': X_test, 'y_test': y_test_cat
        }
        
        for name, data in splits.items():
            np.save(os.path.join(self.output_path, f'{name}.npy'), data)
        
        print(f"Data splits created:")
        print(f"  Train: {X_train.shape[0]} samples")
        print(f"  Validation: {X_val.shape[0]} samples")
        print(f"  Test: {X_test.shape[0]} samples")
        
        return X_train, X_val, X_test, y_train_cat, y_val_cat, y_test_cat
    
    def visualize_samples(self, X, y, num_samples=16):
        """Visualize sample images from the dataset"""
        plt.figure(figsize=(12, 12))
        
        for i in range(min(num_samples, len(X))):
            plt.subplot(4, 4, i + 1)
            plt.imshow(X[i])
            plt.title(f"Class: {self.labels[y[i]]}")
            plt.axis('off')
        
        plt.tight_layout()
        plt.savefig(os.path.join(self.output_path, 'sample_images.png'))
        plt.show()
    
    def create_class_distribution_plot(self, y):
        """Create class distribution plot"""
        class_counts = np.bincount(y)
        
        plt.figure(figsize=(15, 6))
        plt.bar(self.labels, class_counts)
        plt.title('Class Distribution in ISL Dataset')
        plt.xlabel('Letter Class')
        plt.ylabel('Number of Images')
        plt.xticks(rotation=45)
        plt.tight_layout()
        plt.savefig(os.path.join(self.output_path, 'class_distribution.png'))
        plt.show()
    
    def run_preprocessing_pipeline(self):
        """Run the complete preprocessing pipeline"""
        print("=" * 60)
        print("ISL DATA PREPROCESSING PIPELINE")
        print("=" * 60)
        
        try:
            # Step 1: Analyze dataset
            stats = self.analyze_dataset()
            
            # Step 2: Preprocess images
            X, y = self.preprocess_images(augment_data=True, augmentation_factor=2)
            
            # Step 3: Create train/test splits
            X_train, X_val, X_test, y_train, y_val, y_test = self.create_train_test_split(X, y)
            
            # Step 4: Visualize results
            self.visualize_samples(X, y)
            self.create_class_distribution_plot(y)
            
            print("\n" + "=" * 60)
            print("PREPROCESSING COMPLETED!")
            print("=" * 60)
            print(f"Processed data saved to: {self.output_path}")
            print("Files created:")
            print("  - X_processed.npy: All processed images")
            print("  - y_processed.npy: All labels")
            print("  - X_train.npy, y_train.npy: Training data")
            print("  - X_val.npy, y_val.npy: Validation data")
            print("  - X_test.npy, y_test.npy: Test data")
            print("  - metadata.json: Dataset metadata")
            print("  - dataset_analysis.json: Analysis results")
            print("  - sample_images.png: Sample visualization")
            print("  - class_distribution.png: Class distribution plot")
            
        except Exception as e:
            print(f"Error in preprocessing pipeline: {e}")
            print("Please check your dataset and try again")

if __name__ == "__main__":
    # Create preprocessor instance
    preprocessor = ISLDataPreprocessor()
    
    # Run preprocessing pipeline
    preprocessor.run_preprocessing_pipeline()
