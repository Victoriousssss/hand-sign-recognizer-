import cv2
from cvzone.HandTrackingModule import HandDetector
from cvzone.ClassificationModule import Classifier
import numpy as np
import math

# Initialize camera and detectors
cap = cv2.VideoCapture(0)
detector = HandDetector(maxHands=1)
classifier = Classifier('keras_model.h5', "labels.txt")

# Parameters
offset = 20
imgSize = 300

# Load labels from file
with open("labels.txt", "r") as f:
    labels = [line.strip().split()[1] for line in f.readlines()]

print(f"Loaded {len(labels)} alphabet classes: {labels}")
print("Instructions:")
print("- Show hand gestures for letters A-Z")
print("- Press 'q' to quit")
print("- Press 'c' to clear the current word")

# Variables for word building
detected_word = ""
current_letter = "None"
last_letter = "None"
letter_count = 0
letter_threshold = 5  # Number of frames to hold letter before adding to word

while True:
    success, img = cap.read()
    imgOutput = img.copy()
    hands, img = detector.findHands(img, draw=False)
    
    if hands:
        hand = hands[0]
        x, y, w, h = hand['bbox']

        # Create white background for classification
        imgWhite = np.ones((imgSize, imgSize, 3), np.uint8) * 255
        imgCrop = img[y - offset:y + h + offset, x - offset:x + w + offset]

        if imgCrop.size > 0:
            aspectRatio = h / w

            if aspectRatio > 1:
                # Height is greater than width
                k = imgSize / h
                wCal = math.ceil(k * w)
                imgResize = cv2.resize(imgCrop, (wCal, imgSize))
                wGap = math.ceil((imgSize - wCal) / 2)
                imgWhite[:, wGap:wCal + wGap] = imgResize
            else:
                # Width is greater than height
                k = imgSize / w
                hCal = math.ceil(k * h)
                imgResize = cv2.resize(imgCrop, (imgSize, hCal))
                hGap = math.ceil((imgSize - hCal) / 2)
                imgWhite[hGap:hCal + hGap, :] = imgResize

            # Get prediction
            prediction, index = classifier.getPrediction(imgWhite, draw=False)
            confidence = prediction[index]
            
            # Only use prediction if confidence is high enough
            if confidence > 0.7:
                predicted_letter = labels[index]
                
                # Count consecutive predictions of the same letter
                if predicted_letter == last_letter:
                    letter_count += 1
                else:
                    letter_count = 1
                    last_letter = predicted_letter
                
                # Add letter to word if held long enough
                if letter_count >= letter_threshold and predicted_letter != current_letter:
                    detected_word += predicted_letter
                    current_letter = predicted_letter
                    print(f"Added '{predicted_letter}' to word. Current word: '{detected_word}'")
                
                # Draw prediction info
                cv2.rectangle(imgOutput, (x - offset, y - offset - 100),
                            (x + 200, y - offset - 20), (0, 255, 0), cv2.FILLED)
                cv2.putText(imgOutput, f"Letter: {predicted_letter}", 
                           (x - offset + 5, y - offset - 70), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
                cv2.putText(imgOutput, f"Confidence: {confidence:.2f}", 
                           (x - offset + 5, y - offset - 45), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
                cv2.putText(imgOutput, f"Count: {letter_count}/{letter_threshold}", 
                           (x - offset + 5, y - offset - 20), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
            else:
                # Low confidence
                cv2.rectangle(imgOutput, (x - offset, y - offset - 60),
                            (x + 150, y - offset - 20), (0, 0, 255), cv2.FILLED)
                cv2.putText(imgOutput, "Low Confidence", 
                           (x - offset + 5, y - offset - 30), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)

        # Draw hand bounding box
        cv2.rectangle(imgOutput, (x - offset, y - offset),
                     (x + w + offset, y + h + offset), (0, 255, 0), 2)

        # Show processed images
        cv2.imshow("Hand Crop", imgCrop)
        cv2.imshow("Processed Hand", imgWhite)
    else:
        # No hand detected
        cv2.putText(imgOutput, "No Hand Detected", 
                   (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)

    # Display current word
    cv2.putText(imgOutput, f"Current Word: {detected_word}", 
               (10, 70), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2)
    
    # Draw current alphabet in top right corner
    if current_letter != "None":
        # Get image dimensions
        height, width = imgOutput.shape[:2]
        
        # Create background box for current letter
        box_width = 200
        box_height = 80
        x_pos = width - box_width - 20
        y_pos = 20
        
        # Draw background rectangle
        cv2.rectangle(imgOutput, (x_pos, y_pos), (x_pos + box_width, y_pos + box_height), (0, 100, 200), -1)
        cv2.rectangle(imgOutput, (x_pos, y_pos), (x_pos + box_width, y_pos + box_height), (255, 255, 255), 2)
        
        # Draw current letter
        cv2.putText(imgOutput, f"Current Letter: {current_letter}", 
                   (x_pos + 10, y_pos + 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
        
        # Draw letter info
        cv2.putText(imgOutput, f"Hold to add to word", 
                   (x_pos + 10, y_pos + 55), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
    
    # Display instructions
    cv2.putText(imgOutput, "Press 'c' to clear word, 'q' to quit", 
               (10, img.shape[0] - 20), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)

    cv2.imshow("Alphabet Detection", imgOutput)
    
    # Handle key presses
    key = cv2.waitKey(1) & 0xFF
    if key == ord('q'):
        break
    elif key == ord('c'):
        detected_word = ""
        current_letter = "None"
        last_letter = "None"
        letter_count = 0
        print("Word cleared!")

# Cleanup
cap.release()
cv2.destroyAllWindows()
print(f"Final word: '{detected_word}'")
