import cv2
import numpy as np

class ComprehensiveHelpSystem:
    def __init__(self):
        self.alphabet_gestures = {
            'A': {
                'description': 'Fist with thumb extended to the side',
                'instructions': 'Make a fist with all fingers closed, extend the thumb to the side (not forward)',
                'tips': 'Keep the thumb perpendicular to the other fingers, not pointing forward',
                'difficulty': 'Easy'
            },
            'B': {
                'description': 'All fingers extended, palm facing forward',
                'instructions': 'Extend all five fingers straight up, palm facing forward',
                'tips': 'Keep fingers straight and slightly apart, palm flat',
                'difficulty': 'Easy'
            },
            'C': {
                'description': 'Fingers curved like a C shape',
                'instructions': 'Curve all fingers to form a C shape, thumb and fingers creating a semi-circle',
                'tips': 'Make sure the opening of the C is clearly visible',
                'difficulty': 'Medium'
            },
            'D': {
                'description': 'Index finger pointing up, other fingers closed',
                'instructions': 'Extend only the index finger upward, close all other fingers including thumb',
                'tips': 'Keep the index finger straight and pointing directly up',
                'difficulty': 'Easy'
            },
            'E': {
                'description': 'All fingers closed, thumb across fingers',
                'instructions': 'Make a fist with all fingers closed, place thumb across the closed fingers',
                'tips': 'The thumb should rest on top of the closed fingers',
                'difficulty': 'Easy'
            },
            'F': {
                'description': 'Index and middle finger extended, others closed',
                'instructions': 'Extend index and middle finger together, close ring finger, pinky, and thumb',
                'tips': 'Keep the two extended fingers close together',
                'difficulty': 'Easy'
            },
            'G': {
                'description': 'Index finger pointing forward, others closed',
                'instructions': 'Point index finger forward (like pointing), close all other fingers',
                'tips': 'Keep the index finger straight and pointing forward',
                'difficulty': 'Easy'
            },
            'H': {
                'description': 'Index and middle finger extended side by side',
                'instructions': 'Extend index and middle finger side by side, close other fingers',
                'tips': 'Keep both fingers straight and parallel to each other',
                'difficulty': 'Easy'
            },
            'I': {
                'description': 'Pinky finger extended, others closed',
                'instructions': 'Extend only the pinky finger, close all other fingers including thumb',
                'tips': 'Keep the pinky straight and pointing up',
                'difficulty': 'Easy'
            },
            'J': {
                'description': 'Pinky finger extended, make J motion',
                'instructions': 'Start with pinky extended, then make a J-shaped motion',
                'tips': 'The motion should trace the letter J in the air',
                'difficulty': 'Hard'
            },
            'K': {
                'description': 'Index and middle finger extended, thumb between them',
                'instructions': 'Extend index and middle finger, place thumb between them',
                'tips': 'The thumb should be positioned between the two extended fingers',
                'difficulty': 'Hard'
            },
            'L': {
                'description': 'Index finger and thumb extended, others closed',
                'instructions': 'Extend index finger and thumb, close middle, ring, and pinky fingers',
                'tips': 'Form an L shape with index finger and thumb',
                'difficulty': 'Easy'
            },
            'M': {
                'description': 'All fingers closed, thumb under other fingers',
                'instructions': 'Make a fist with all fingers closed, thumb tucked under the other fingers',
                'tips': 'The thumb should be completely hidden under the other fingers',
                'difficulty': 'Medium'
            },
            'N': {
                'description': 'Index and middle finger closed, others extended',
                'instructions': 'Close index and middle finger, extend ring finger, pinky, and thumb',
                'tips': 'Keep the closed fingers together, extended fingers spread',
                'difficulty': 'Hard'
            },
            'O': {
                'description': 'All fingers curved to form O shape',
                'instructions': 'Curve all fingers to form a perfect O shape',
                'tips': 'Make sure the O is round and complete',
                'difficulty': 'Medium'
            },
            'P': {
                'description': 'Index finger pointing up, middle finger down, others closed',
                'instructions': 'Point index finger up, middle finger down, close other fingers',
                'tips': 'Create a clear contrast between up and down fingers',
                'difficulty': 'Hard'
            },
            'Q': {
                'description': 'Index finger and thumb extended, others closed',
                'instructions': 'Extend index finger and thumb, close middle, ring, and pinky fingers',
                'tips': 'Similar to L but with different positioning',
                'difficulty': 'Easy'
            },
            'R': {
                'description': 'Index and middle finger crossed',
                'instructions': 'Extend index and middle finger and cross them over each other',
                'tips': 'Make sure the crossing is clearly visible',
                'difficulty': 'Hard'
            },
            'S': {
                'description': 'Fist with thumb across fingers',
                'instructions': 'Make a fist with all fingers closed, thumb across the closed fingers',
                'tips': 'Similar to E but with thumb positioned differently',
                'difficulty': 'Easy'
            },
            'T': {
                'description': 'Fist with thumb between index and middle finger',
                'instructions': 'Make a fist, place thumb between index and middle finger',
                'tips': 'The thumb should be clearly visible between the two fingers',
                'difficulty': 'Medium'
            },
            'U': {
                'description': 'Index and middle finger extended together',
                'instructions': 'Extend index and middle finger together, close other fingers',
                'tips': 'Keep both fingers straight and touching each other',
                'difficulty': 'Easy'
            },
            'V': {
                'description': 'Index and middle finger extended apart',
                'instructions': 'Extend index and middle finger apart from each other',
                'tips': 'Create a clear V shape with the two fingers',
                'difficulty': 'Easy'
            },
            'W': {
                'description': 'Index, middle, and ring finger extended',
                'instructions': 'Extend index, middle, and ring finger, close pinky and thumb',
                'tips': 'Keep the three extended fingers spread apart',
                'difficulty': 'Medium'
            },
            'X': {
                'description': 'Index finger bent, others closed',
                'instructions': 'Bend the index finger, close all other fingers',
                'tips': 'Make sure the bend in the index finger is clearly visible',
                'difficulty': 'Medium'
            },
            'Y': {
                'description': 'Thumb and pinky extended, others closed',
                'instructions': 'Extend thumb and pinky finger, close index, middle, and ring fingers',
                'tips': 'Create a clear Y shape with thumb and pinky',
                'difficulty': 'Medium'
            },
            'Z': {
                'description': 'Index finger moving in Z pattern',
                'instructions': 'Use index finger to trace a Z shape in the air',
                'tips': 'Make the Z motion clear and deliberate',
                'difficulty': 'Hard'
            }
        }
        
        self.current_letter = 'A'
        self.letters = list(self.alphabet_gestures.keys())
        self.current_index = 0
        self.show_mode = 'single'  # 'single', 'all', 'difficulty'

    def get_difficulty_color(self, difficulty):
        """Get color based on difficulty level"""
        if difficulty == 'Easy':
            return (0, 255, 0)  # Green
        elif difficulty == 'Medium':
            return (0, 255, 255)  # Yellow
        else:  # Hard
            return (0, 0, 255)  # Red

    def draw_single_letter_view(self, img):
        """Draw detailed view of a single letter"""
        height, width = img.shape[:2]
        
        # Semi-transparent overlay
        overlay = img.copy()
        cv2.rectangle(overlay, (0, 0), (width, height), (0, 0, 0), -1)
        cv2.addWeighted(overlay, 0.8, img, 0.2, 0, img)
        
        # Title
        cv2.putText(img, "INDIAN SIGN LANGUAGE ALPHABET GUIDE", 
                   (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1.5, (0, 255, 255), 3)
        
        # Current letter display
        letter_info = self.alphabet_gestures[self.current_letter]
        cv2.putText(img, f"LETTER: {self.current_letter}", 
                   (50, 100), cv2.FONT_HERSHEY_SIMPLEX, 2, (0, 255, 0), 3)
        
        # Difficulty indicator
        difficulty_color = self.get_difficulty_color(letter_info['difficulty'])
        cv2.putText(img, f"Difficulty: {letter_info['difficulty']}", 
                   (50, 140), cv2.FONT_HERSHEY_SIMPLEX, 1, difficulty_color, 2)
        
        # Description
        cv2.putText(img, f"Description: {letter_info['description']}", 
                   (50, 180), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
        
        # Instructions
        cv2.putText(img, f"Instructions: {letter_info['instructions']}", 
                   (50, 220), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
        
        # Tips
        cv2.putText(img, f"Tips: {letter_info['tips']}", 
                   (50, 260), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 0), 2)
        
        # Navigation instructions
        cv2.putText(img, "NAVIGATION:", 
                   (50, 320), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2)
        cv2.putText(img, "Press 'A' or 'D' to navigate letters", 
                   (50, 350), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
        cv2.putText(img, "Press 'SPACE' to see all letters", 
                   (50, 380), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
        cv2.putText(img, "Press 'F' to filter by difficulty", 
                   (50, 410), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
        cv2.putText(img, "Press 'Q' to quit", 
                   (50, 440), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
        
        # Show current letter position
        cv2.putText(img, f"Letter {self.current_index + 1} of {len(self.letters)}", 
                   (50, 480), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)

    def draw_all_letters_view(self, img):
        """Draw all letters in a grid format"""
        height, width = img.shape[:2]
        
        # Semi-transparent overlay
        overlay = img.copy()
        cv2.rectangle(overlay, (0, 0), (width, height), (0, 0, 0), -1)
        cv2.addWeighted(overlay, 0.9, img, 0.1, 0, img)
        
        # Title
        cv2.putText(img, "ALL INDIAN SIGN LANGUAGE ALPHABET GESTURES", 
                   (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1.2, (0, 255, 255), 2)
        
        # Create a grid of letters
        letters_per_row = 6
        start_x = 50
        start_y = 100
        letter_width = 150
        letter_height = 80
        row_spacing = 100
        
        for i, letter in enumerate(self.letters):
            row = i // letters_per_row
            col = i % letters_per_row
            
            x = start_x + col * letter_width
            y = start_y + row * row_spacing
            
            # Get difficulty color
            difficulty = self.alphabet_gestures[letter]['difficulty']
            difficulty_color = self.get_difficulty_color(difficulty)
            
            # Draw letter box with difficulty color
            cv2.rectangle(img, (x, y), (x + letter_width - 10, y + letter_height), difficulty_color, 2)
            
            # Draw letter
            cv2.putText(img, letter, (x + 10, y + 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
            
            # Draw difficulty
            cv2.putText(img, difficulty, (x + 10, y + 50), cv2.FONT_HERSHEY_SIMPLEX, 0.4, difficulty_color, 1)
            
            # Draw description (truncated)
            desc = self.alphabet_gestures[letter]['description']
            if len(desc) > 20:
                desc = desc[:20] + "..."
            cv2.putText(img, desc, (x + 10, y + 70), cv2.FONT_HERSHEY_SIMPLEX, 0.3, (255, 255, 255), 1)
        
        # Instructions
        cv2.putText(img, "Press 'SPACE' to return to single letter view", 
                   (50, height - 100), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
        cv2.putText(img, "Press 'Q' to quit", 
                   (50, height - 70), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)

    def draw_difficulty_filter_view(self, img):
        """Draw letters filtered by difficulty"""
        height, width = img.shape[:2]
        
        # Semi-transparent overlay
        overlay = img.copy()
        cv2.rectangle(overlay, (0, 0), (width, height), (0, 0, 0), -1)
        cv2.addWeighted(overlay, 0.9, img, 0.1, 0, img)
        
        # Title
        cv2.putText(img, "LETTERS BY DIFFICULTY LEVEL", 
                   (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1.2, (0, 255, 255), 2)
        
        # Group letters by difficulty
        easy_letters = [l for l in self.letters if self.alphabet_gestures[l]['difficulty'] == 'Easy']
        medium_letters = [l for l in self.letters if self.alphabet_gestures[l]['difficulty'] == 'Medium']
        hard_letters = [l for l in self.letters if self.alphabet_gestures[l]['difficulty'] == 'Hard']
        
        # Draw Easy letters
        cv2.putText(img, "EASY LETTERS (Green):", (50, 100), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
        for i, letter in enumerate(easy_letters):
            x = 50 + (i % 8) * 80
            y = 130 + (i // 8) * 30
            cv2.putText(img, letter, (x, y), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
        
        # Draw Medium letters
        cv2.putText(img, "MEDIUM LETTERS (Yellow):", (50, 200), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2)
        for i, letter in enumerate(medium_letters):
            x = 50 + (i % 8) * 80
            y = 230 + (i // 8) * 30
            cv2.putText(img, letter, (x, y), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 255), 2)
        
        # Draw Hard letters
        cv2.putText(img, "HARD LETTERS (Red):", (50, 300), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
        for i, letter in enumerate(hard_letters):
            x = 50 + (i % 8) * 80
            y = 330 + (i // 8) * 30
            cv2.putText(img, letter, (x, y), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)
        
        # Instructions
        cv2.putText(img, "Press 'SPACE' to return to single letter view", 
                   (50, height - 100), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
        cv2.putText(img, "Press 'Q' to quit", 
                   (50, height - 70), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)

    def run(self):
        """Main help system loop"""
        print("Comprehensive Indian Sign Language Alphabet Help System")
        print("Instructions:")
        print("- Press 'A' or 'D' to navigate through letters")
        print("- Press 'SPACE' to see all letters at once")
        print("- Press 'F' to filter by difficulty level")
        print("- Press 'Q' to quit")
        
        while True:
            # Create a black background
            img = np.zeros((800, 1200, 3), np.uint8)
            
            if self.show_mode == 'single':
                self.draw_single_letter_view(img)
            elif self.show_mode == 'all':
                self.draw_all_letters_view(img)
            elif self.show_mode == 'difficulty':
                self.draw_difficulty_filter_view(img)
            
            cv2.imshow("ISL Comprehensive Help System", img)
            
            key = cv2.waitKey(0) & 0xFF
            
            if key == ord('q') or key == ord('Q'):
                break
            elif key == ord('a') or key == ord('A'):
                # Previous letter
                self.current_index = (self.current_index - 1) % len(self.letters)
                self.current_letter = self.letters[self.current_index]
                self.show_mode = 'single'
            elif key == ord('d') or key == ord('D'):
                # Next letter
                self.current_index = (self.current_index + 1) % len(self.letters)
                self.current_letter = self.letters[self.current_index]
                self.show_mode = 'single'
            elif key == ord(' '):
                # Toggle all letters view
                if self.show_mode == 'single':
                    self.show_mode = 'all'
                else:
                    self.show_mode = 'single'
            elif key == ord('f') or key == ord('F'):
                # Toggle difficulty filter
                if self.show_mode == 'difficulty':
                    self.show_mode = 'single'
                else:
                    self.show_mode = 'difficulty'
            elif key >= ord('a') and key <= ord('z'):
                # Jump to specific letter
                letter = chr(key).upper()
                if letter in self.letters:
                    self.current_letter = letter
                    self.current_index = self.letters.index(letter)
                    self.show_mode = 'single'
        
        cv2.destroyAllWindows()

if __name__ == "__main__":
    help_system = ComprehensiveHelpSystem()
    help_system.run()
