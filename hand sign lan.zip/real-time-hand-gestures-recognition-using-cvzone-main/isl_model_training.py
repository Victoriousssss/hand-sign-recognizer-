import os
import numpy as np
import json
import matplotlib.pyplot as plt
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import Dense, Conv2D, MaxPooling2D, Flatten, Dropout, BatchNormalization, GlobalAveragePooling2D
from tensorflow.keras.optimizers import Adam, RMSprop
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau, ModelCheckpoint, CSVLogger
from tensorflow.keras.applications import MobileNetV2, ResNet50, EfficientNetB0
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from sklearn.metrics import classification_report, confusion_matrix
import seaborn as sns

class ISLModelTrainer:
    def __init__(self, data_path="processed_isl_dataset", model_save_path="isl_trained_model.h5"):
        self.data_path = data_path
        self.model_save_path = model_save_path
        self.labels = [chr(i) for i in range(ord('A'), ord('Z') + 1)]  # A-Z
        self.num_classes = len(self.labels)
        self.img_size = 224
        
    def load_processed_data(self):
        """Load preprocessed data"""
        print("Loading processed data...")
        
        try:
            # Load data splits
            X_train = np.load(os.path.join(self.data_path, 'X_train.npy'))
            y_train = np.load(os.path.join(self.data_path, 'y_train.npy'))
            X_val = np.load(os.path.join(self.data_path, 'X_val.npy'))
            y_val = np.load(os.path.join(self.data_path, 'y_val.npy'))
            X_test = np.load(os.path.join(self.data_path, 'X_test.npy'))
            y_test = np.load(os.path.join(self.data_path, 'y_test.npy'))
            
            # Load metadata
            with open(os.path.join(self.data_path, 'metadata.json'), 'r') as f:
                metadata = json.load(f)
            
            print(f"Data loaded successfully:")
            print(f"  Train: {X_train.shape[0]} samples")
            print(f"  Validation: {X_val.shape[0]} samples")
            print(f"  Test: {X_test.shape[0]} samples")
            print(f"  Image shape: {X_train.shape[1:]}")
            print(f"  Number of classes: {self.num_classes}")
            
            return X_train, y_train, X_val, y_val, X_test, y_test, metadata
            
        except FileNotFoundError as e:
            print(f"Error loading data: {e}")
            print("Please run the preprocessing script first")
            return None, None, None, None, None, None, None
    
    def create_custom_cnn_model(self):
        """Create a custom CNN model for ISL recognition"""
        model = Sequential([
            # First Convolutional Block
            Conv2D(32, (3, 3), activation='relu', input_shape=(self.img_size, self.img_size, 3)),
            BatchNormalization(),
            MaxPooling2D(2, 2),
            Dropout(0.25),
            
            # Second Convolutional Block
            Conv2D(64, (3, 3), activation='relu'),
            BatchNormalization(),
            MaxPooling2D(2, 2),
            Dropout(0.25),
            
            # Third Convolutional Block
            Conv2D(128, (3, 3), activation='relu'),
            BatchNormalization(),
            MaxPooling2D(2, 2),
            Dropout(0.25),
            
            # Fourth Convolutional Block
            Conv2D(256, (3, 3), activation='relu'),
            BatchNormalization(),
            MaxPooling2D(2, 2),
            Dropout(0.25),
            
            # Fifth Convolutional Block
            Conv2D(512, (3, 3), activation='relu'),
            BatchNormalization(),
            GlobalAveragePooling2D(),
            Dropout(0.5),
            
            # Dense Layers
            Dense(512, activation='relu'),
            BatchNormalization(),
            Dropout(0.5),
            Dense(256, activation='relu'),
            BatchNormalization(),
            Dropout(0.3),
            Dense(self.num_classes, activation='softmax')
        ])
        
        return model
    
    def create_transfer_learning_model(self, base_model_name='mobilenet'):
        """Create a transfer learning model"""
        if base_model_name == 'mobilenet':
            base_model = MobileNetV2(
                weights='imagenet',
                include_top=False,
                input_shape=(self.img_size, self.img_size, 3)
            )
        elif base_model_name == 'resnet':
            base_model = ResNet50(
                weights='imagenet',
                include_top=False,
                input_shape=(self.img_size, self.img_size, 3)
            )
        elif base_model_name == 'efficientnet':
            base_model = EfficientNetB0(
                weights='imagenet',
                include_top=False,
                input_shape=(self.img_size, self.img_size, 3)
            )
        else:
            raise ValueError("Unsupported base model")
        
        # Freeze base model layers
        base_model.trainable = False
        
        model = Sequential([
            base_model,
            GlobalAveragePooling2D(),
            Dropout(0.5),
            Dense(512, activation='relu'),
            BatchNormalization(),
            Dropout(0.5),
            Dense(256, activation='relu'),
            BatchNormalization(),
            Dropout(0.3),
            Dense(self.num_classes, activation='softmax')
        ])
        
        return model, base_model
    
    def compile_model(self, model, learning_rate=0.001):
        """Compile the model"""
        model.compile(
            optimizer=Adam(learning_rate=learning_rate),
            loss='categorical_crossentropy',
            metrics=['accuracy', 'top_3_accuracy']
        )
        
        return model
    
    def create_data_generators(self, X_train, y_train, X_val, y_val, batch_size=32):
        """Create data generators for training"""
        # Data augmentation for training
        train_datagen = ImageDataGenerator(
            rotation_range=15,
            width_shift_range=0.1,
            height_shift_range=0.1,
            shear_range=0.1,
            zoom_range=0.1,
            horizontal_flip=False,  # Don't flip for sign language
            fill_mode='nearest'
        )
        
        # No augmentation for validation
        val_datagen = ImageDataGenerator()
        
        # Create generators
        train_generator = train_datagen.flow(X_train, y_train, batch_size=batch_size)
        val_generator = val_datagen.flow(X_val, y_val, batch_size=batch_size)
        
        return train_generator, val_generator
    
    def create_callbacks(self, model_name="isl_model"):
        """Create training callbacks"""
        callbacks = [
            # Early stopping
            EarlyStopping(
                monitor='val_accuracy',
                patience=15,
                restore_best_weights=True,
                verbose=1
            ),
            
            # Reduce learning rate on plateau
            ReduceLROnPlateau(
                monitor='val_loss',
                factor=0.5,
                patience=8,
                min_lr=1e-7,
                verbose=1
            ),
            
            # Model checkpoint
            ModelCheckpoint(
                filepath=f"{model_name}_best.h5",
                monitor='val_accuracy',
                save_best_only=True,
                verbose=1
            ),
            
            # CSV logger
            CSVLogger(f"{model_name}_training.log")
        ]
        
        return callbacks
    
    def train_model(self, model_type='custom', epochs=100, batch_size=32, learning_rate=0.001):
        """Train the ISL model"""
        print("=" * 60)
        print("TRAINING ISL MODEL")
        print("=" * 60)
        
        # Load data
        data = self.load_processed_data()
        if data[0] is None:
            return None
        
        X_train, y_train, X_val, y_val, X_test, y_test, metadata = data
        
        # Create model
        if model_type == 'custom':
            print("Creating custom CNN model...")
            model = self.create_custom_cnn_model()
        elif model_type in ['mobilenet', 'resnet', 'efficientnet']:
            print(f"Creating transfer learning model with {model_type}...")
            model, base_model = self.create_transfer_learning_model(model_type)
        else:
            raise ValueError("Unsupported model type")
        
        # Compile model
        model = self.compile_model(model, learning_rate)
        
        # Print model summary
        print("\nModel Architecture:")
        model.summary()
        
        # Create data generators
        train_generator, val_generator = self.create_data_generators(
            X_train, y_train, X_val, y_val, batch_size
        )
        
        # Create callbacks
        callbacks = self.create_callbacks(f"isl_{model_type}")
        
        # Train model
        print(f"\nStarting training for {epochs} epochs...")
        history = model.fit(
            train_generator,
            steps_per_epoch=len(X_train) // batch_size,
            epochs=epochs,
            validation_data=val_generator,
            validation_steps=len(X_val) // batch_size,
            callbacks=callbacks,
            verbose=1
        )
        
        # Save final model
        model.save(self.model_save_path)
        print(f"Model saved to: {self.model_save_path}")
        
        # Fine-tuning for transfer learning models
        if model_type in ['mobilenet', 'resnet', 'efficientnet']:
            print("\nStarting fine-tuning...")
            self._fine_tune_model(model, base_model, train_generator, val_generator, callbacks)
        
        return model, history
    
    def _fine_tune_model(self, model, base_model, train_generator, val_generator, callbacks):
        """Fine-tune the transfer learning model"""
        # Unfreeze some layers for fine-tuning
        base_model.trainable = True
        
        # Fine-tune from this layer onwards
        fine_tune_at = len(base_model.layers) - 30
        
        # Freeze all the layers before the `fine_tune_at` layer
        for layer in base_model.layers[:fine_tune_at]:
            layer.trainable = False
        
        # Recompile with lower learning rate
        model.compile(
            optimizer=Adam(learning_rate=0.0001),
            loss='categorical_crossentropy',
            metrics=['accuracy', 'top_3_accuracy']
        )
        
        # Continue training
        model.fit(
            train_generator,
            steps_per_epoch=len(train_generator),
            epochs=20,  # Additional epochs for fine-tuning
            validation_data=val_generator,
            validation_steps=len(val_generator),
            callbacks=callbacks,
            verbose=1
        )
    
    def evaluate_model(self, model, X_test, y_test):
        """Evaluate the trained model"""
        print("\n" + "=" * 60)
        print("MODEL EVALUATION")
        print("=" * 60)
        
        # Get predictions
        predictions = model.predict(X_test)
        predicted_classes = np.argmax(predictions, axis=1)
        true_classes = np.argmax(y_test, axis=1)
        
        # Calculate metrics
        accuracy = np.mean(predicted_classes == true_classes)
        top3_accuracy = self._calculate_top_k_accuracy(predictions, true_classes, k=3)
        
        print(f"Test Accuracy: {accuracy:.4f}")
        print(f"Top-3 Accuracy: {top3_accuracy:.4f}")
        
        # Classification report
        print("\nClassification Report:")
        report = classification_report(true_classes, predicted_classes, target_names=self.labels)
        print(report)
        
        # Confusion matrix
        self._plot_confusion_matrix(true_classes, predicted_classes)
        
        # Per-class accuracy
        self._plot_per_class_accuracy(true_classes, predicted_classes)
        
        return accuracy, top3_accuracy
    
    def _calculate_top_k_accuracy(self, predictions, true_classes, k=3):
        """Calculate top-k accuracy"""
        top_k_predictions = np.argsort(predictions, axis=1)[:, -k:]
        correct = 0
        for i, true_class in enumerate(true_classes):
            if true_class in top_k_predictions[i]:
                correct += 1
        return correct / len(true_classes)
    
    def _plot_confusion_matrix(self, true_classes, predicted_classes):
        """Plot confusion matrix"""
        cm = confusion_matrix(true_classes, predicted_classes)
        
        plt.figure(figsize=(15, 12))
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                   xticklabels=self.labels, yticklabels=self.labels)
        plt.title('Confusion Matrix - ISL Recognition')
        plt.xlabel('Predicted Class')
        plt.ylabel('True Class')
        plt.tight_layout()
        plt.savefig('confusion_matrix.png')
        plt.show()
    
    def _plot_per_class_accuracy(self, true_classes, predicted_classes):
        """Plot per-class accuracy"""
        class_accuracy = []
        for i in range(self.num_classes):
            class_mask = true_classes == i
            if np.sum(class_mask) > 0:
                accuracy = np.mean(predicted_classes[class_mask] == true_classes[class_mask])
                class_accuracy.append(accuracy)
            else:
                class_accuracy.append(0)
        
        plt.figure(figsize=(15, 6))
        bars = plt.bar(self.labels, class_accuracy)
        plt.title('Per-Class Accuracy - ISL Recognition')
        plt.xlabel('Letter Class')
        plt.ylabel('Accuracy')
        plt.xticks(rotation=45)
        
        # Color bars based on accuracy
        for bar, acc in zip(bars, class_accuracy):
            if acc >= 0.9:
                bar.set_color('green')
            elif acc >= 0.7:
                bar.set_color('orange')
            else:
                bar.set_color('red')
        
        plt.tight_layout()
        plt.savefig('per_class_accuracy.png')
        plt.show()
    
    def plot_training_history(self, history):
        """Plot training history"""
        plt.figure(figsize=(15, 5))
        
        # Plot accuracy
        plt.subplot(1, 3, 1)
        plt.plot(history.history['accuracy'], label='Training Accuracy')
        plt.plot(history.history['val_accuracy'], label='Validation Accuracy')
        plt.title('Model Accuracy')
        plt.xlabel('Epoch')
        plt.ylabel('Accuracy')
        plt.legend()
        
        # Plot loss
        plt.subplot(1, 3, 2)
        plt.plot(history.history['loss'], label='Training Loss')
        plt.plot(history.history['val_loss'], label='Validation Loss')
        plt.title('Model Loss')
        plt.xlabel('Epoch')
        plt.ylabel('Loss')
        plt.legend()
        
        # Plot top-3 accuracy if available
        plt.subplot(1, 3, 3)
        if 'top_3_accuracy' in history.history:
            plt.plot(history.history['top_3_accuracy'], label='Training Top-3 Accuracy')
            plt.plot(history.history['val_top_3_accuracy'], label='Validation Top-3 Accuracy')
            plt.title('Top-3 Accuracy')
            plt.xlabel('Epoch')
            plt.ylabel('Top-3 Accuracy')
            plt.legend()
        
        plt.tight_layout()
        plt.savefig('training_history.png')
        plt.show()
    
    def create_labels_file(self):
        """Create labels.txt file for detection scripts"""
        labels_path = "isl_labels.txt"
        
        with open(labels_path, 'w') as f:
            for i, letter in enumerate(self.labels):
                f.write(f"{i} {letter}\n")
        
        print(f"Labels file created: {labels_path}")
        return labels_path
    
    def run_training_pipeline(self, model_type='custom', epochs=100):
        """Run the complete training pipeline"""
        print("=" * 60)
        print("ISL MODEL TRAINING PIPELINE")
        print("=" * 60)
        
        try:
            # Load data
            data = self.load_processed_data()
            if data[0] is None:
                return
            
            X_train, y_train, X_val, y_val, X_test, y_test, metadata = data
            
            # Train model
            model, history = self.train_model(model_type, epochs)
            
            # Evaluate model
            accuracy, top3_accuracy = self.evaluate_model(model, X_test, y_test)
            
            # Plot training history
            self.plot_training_history(history)
            
            # Create labels file
            self.create_labels_file()
            
            print("\n" + "=" * 60)
            print("TRAINING COMPLETED!")
            print("=" * 60)
            print(f"Final Test Accuracy: {accuracy:.4f}")
            print(f"Final Top-3 Accuracy: {top3_accuracy:.4f}")
            print(f"Model saved to: {self.model_save_path}")
            print(f"Labels file: isl_labels.txt")
            print("\nTo use with detection scripts:")
            print("1. Copy the trained model to your detection script directory")
            print("2. Copy isl_labels.txt to your detection script directory")
            print("3. Update your detection script to use the new model")
            
        except Exception as e:
            print(f"Error in training pipeline: {e}")
            print("Please check your data and try again")

if __name__ == "__main__":
    # Create trainer instance
    trainer = ISLModelTrainer()
    
    # Run training pipeline
    print("Available model types:")
    print("1. custom - Custom CNN model")
    print("2. mobilenet - MobileNetV2 transfer learning")
    print("3. resnet - ResNet50 transfer learning")
    print("4. efficientnet - EfficientNetB0 transfer learning")
    
    model_type = input("Choose model type (custom/mobilenet/resnet/efficientnet): ").strip().lower()
    if not model_type:
        model_type = 'custom'
    
    epochs = input("Number of epochs (default 100): ").strip()
    epochs = int(epochs) if epochs.isdigit() else 100
    
    trainer.run_training_pipeline(model_type, epochs)
